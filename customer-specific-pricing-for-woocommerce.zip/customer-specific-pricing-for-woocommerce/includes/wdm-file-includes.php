<?php

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

	// Add this where you want to include this file

	// add_action('wp_loaded', 'includeFiles', 1);


	//     /*
	//  * This function includes required files
	//  */
	// function includeFiles()
	// {
	//     //Includes required files
	//     require_once CSP_PLUGIN_PATH.'/wdm-file-includes.php';
	// }


// Include all files over here now onwards
