<?php

namespace cspAjax;

if (!class_exists('WdmWuspAjax')) {

	/**
	 * Class for various ajax callbacks in CSP.
	 */
	class WdmWuspAjax
	{


		/**
		 * Adds the ajax callback actions in CSP:
		 * Ajax action for creating csv.
		 * Ajax action for rule-type selection in Product-pricing tab.
		 * Ajax action for updating options table for notice dismissal.
		 * Ajax action for selecting product-titles and their specific pricing
		 * Ajax action for saving the rule log of product pricings.
		 * Ajax action for Progress status from the options table.
		 * Ajax action for getting the selection in search by tab.
		 * Ajax action for displaying selection list for various entities
		 * pricings
		 * Ajax action for deleting the rule from rule log.
		 * Ajax action for dropping the batch numbers column from the table.
		 */

		public function __construct()
		{
			add_action('wp_ajax_create_csv', array($this, 'wdmCreateCsv'));
			add_action('wp_ajax_create_csv_bulk', array($this, 'wdmCreateCsvForBulkDiscounts'));
			add_action('wp_ajax_csp_get_product_list', array($this, 'wdmCreateProductListCSV'));
			add_action('wp_ajax_csp_get_all_rules_backup', array($this, 'wdmCreateBackupForAllRules'));

			add_action('wp_ajax_get_type_selection_result', array($this, 'getTypeSelectionResultCallback'));

			add_action('wp_ajax_get_product_price_list', array($this, 'getProductPriceListCallback'));

			add_action('wp_ajax_save_query_log', array($this, 'saveQueryLogCallback'));

			add_action('wp_ajax_get_progress_status', array($this, 'getProgressStatusCallback'));

			add_action('wp_ajax_get_search_selection_result', array($this, 'getSearchSelectionCallback'));

			add_action('wp_ajax_display_product_prices_selection', array($this, 'displayProductPricesCallback'));

			add_action('wp_ajax_remove_single_csp_price', array($this, 'removeSingleRecordCSPPrice'));

			// Callback to remove the CSP price records when 'Delete' button is clicked in
			// 'Search by & Delete' tab in the admin section.
			add_action('wp_ajax_remove_bulk_csp_price', array($this, 'removeBulkRecordCSPPrice'));

			add_action('wp_ajax_remove_query_log', array($this, 'removeQueryLogCallback'));

			add_action('wp_ajax_drop_batch_numbers', array($this, 'dropBatchNumbers'));

			add_action('wp_ajax_csp_download_report', array($this, 'generateAndDownloadReport'));

			add_action('wp_ajax_csp_set_gd_feature_status', array($this, 'setGlobalDiscountFeatureStatus'));
			add_action('wp_ajax_csp_save_gd_rule_data', array($this, 'saveGlobalDiscountRuleData'));

			add_action('wp_ajax_csp_get_users_by_search_term', array($this, 'getUsersBySearchTerm'));

			//Ajax callbacks for the features added in the new import feature
			add_action('wp_ajax_csp_get_import_csv', array($this, 'cspGetValidateImportCSV'));
			add_action('wp_ajax_csp_start_import_process', array($this, 'startImportProcess'));
			add_action('wp_ajax_csp_start_batch_import', array($this, 'startBatchImport'));
			add_action('wp_ajax_csp_download_report_new', array($this, 'generateAndDownloadImportReport'));

			//Ajax callback for the Backups
			add_action('wp_ajax_csp_schedule_backups', array($this, 'saveBackupSchedule'));
			add_action('wp_ajax_csp_stop_scheduled_backups', array($this, 'stopBackupSchedule'));
			add_action('wdm_csp_generate_scheduled_backup', array($this, 'generateScheduledBackup'));
			add_action('wp_ajax_csp_remove_auto_backup_file', array($this, 'removeBackupFile'));
			add_action('wp_ajax_csp_test_ftp_sftp_connection', array($this, 'checkFTPConnection'));
			add_action('wp_ajax_csp_add_update_import_schedule', array($this, 'saveUpdateImportSchedule'));
			add_action('wp_ajax_csp_delete_import_schedule', array($this, 'deleteImportSchedule'));
			add_action('wdm_csp_process_rule_import', array($this, 'importScheduledFile'), 10, 1);
		}


		/**
		 * Gets the file type.
		 * Drop the batch numbers column from the table depending on
		 * rule-type.
		 *
		 */
		public function dropBatchNumbers()
		{
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			$fileType = isset($postArray['file_type']) ? $postArray['file_type'] : '';
			if (!empty($fileType)) {
				$this->deleteBatchColumn($fileType);
			}
			die();
		}

		/**
		 * Delete the column of batch numbers for particular table depending on
		 * rule-type.
		 *
		 * @param string $fileType rule/file type.
		 */
		public function deleteBatchColumn($fileType)
		{
			global $wpdb;

			switch ($fileType) {
				case 'user':
					$cspTable = $wpdb->prefix . 'wusp_user_pricing_mapping';
					$existingColumn = $wpdb->get_var($wpdb->prepare('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = %s AND column_name = %s', $cspTable, 'batch_numbers'));
					if (!empty($existingColumn)) {
						$wpdb->query('ALTER TABLE ' . $wpdb->prefix . 'wusp_user_pricing_mapping DROP COLUMN batch_numbers');
					}
					break;

				case 'role':
					$cspTable = $wpdb->prefix . 'wusp_role_pricing_mapping';
					$existingColumn = $wpdb->get_var($wpdb->prepare('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = %s AND column_name = %s', $cspTable, 'batch_numbers'));
					if (!empty($existingColumn)) {
						$wpdb->query('ALTER TABLE ' . $wpdb->prefix . 'wusp_role_pricing_mapping DROP COLUMN batch_numbers');
					}
					break;

				case 'group':
					$cspTable = $wpdb->prefix . 'wusp_group_product_price_mapping';
					$existingColumn = $wpdb->get_var($wpdb->prepare('SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = %s AND column_name = %s', $cspTable, 'batch_numbers'));
					if (!empty($existingColumn)) {
						$wpdb->query('ALTER TABLE ' . $wpdb->prefix . 'wusp_group_product_price_mapping DROP COLUMN batch_numbers');
					}
					break;
				default:
					# Do nothing...
					break;
			}
		}

		/**
		 * Create csv file for export
		 * Verifies the nonce for export.
		 * Check the capability of the user.
		 * Fetch the data of particular entity specific pricing from DB.
		 * Gets the file name for the csv on basis of entity.
		 * If that file is already present in uploadsdirectory delete that
		 * file and create new file with the data fetched from DB.
		 */
		public function wdmCreateCsv()
		{
			//WdmUserSpecificPricingExport
			$nonce = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');

			/**
			 * * This filter can be used to Override nonce verification for extending import functionality in
			 * any third party extension.
			 * 
			 * @param bool|string $name $nonce_verification nonce name or false to disable nonce verification
			 */
			$nonce_verification = apply_filters('csp_export_nonce_verification', $nonce_verification);
			if (!$nonce_verification) {
				echo 'Security Check';
				exit;
			} else {
				//Allow only admin to import csv files
				/**
				 * Filter to define whayt capability is required for the user to be able to access export functionality.
				 * 
				 * @param string $capability
				 */
				$capability			= apply_filters('csp_get_export_capability', 'manage_options');

				/**
				 * Filter to define whayt capability is required for the user to be able to access export functionality.
				 * 
				 * @param string $capability
				 */
				$capabilityToExport = apply_filters('csp_export_allowed_user_capability', $capability);

				/**
				 * This filter can be used to conditionally allow the user to access the import feature when they do not have the capability to export.
				 * 
				 * @param string $capabilityToExport
				 */
				$can_user_export	= apply_filters('csp_can_user_export_csv', current_user_can($capabilityToExport));
				if (!$can_user_export) {
					echo 'Security Check';
					exit;
				}
			}

			$class_name = isset($_POST['option_val']) ? '\cspImportExport\cspExport\WdmWusp' . sanitize_text_field($_POST['option_val']) . 'SpecificPricingExport' : '';

			if (!empty($class_name)) {
				$export_object = new $class_name();
				$fileUrl 	   = $export_object->getCSVFile('', 'url');
				if (!empty($fileUrl)) {
					echo esc_url($fileUrl);
				} else {
					echo esc_url(menu_page_url('customer_specific_pricing_export'));
				}
			} else {
				echo esc_url(menu_page_url('customer_specific_pricing_export'));
			}
			exit();
		}

		/**
		 * For Product-Pricing tab,
		 * Display the Products and Rule-type selection.
		 * Display the Set Prices module.
		 * If option not selected display error.
		 */
		public function getTypeSelectionResultCallback()
		{
			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_get_type_selection_user_capability', 'manage_options');
			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_select = apply_filters('csp_can_user_get_type_selection', current_user_can($capability_required));
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			if (!$can_user_select) {
				echo 'Security Check';
				exit;
			}

			$option_selection = isset($postArray['option_type']) ? $postArray['option_type'] : '';

			if (!empty($option_selection)) {
				$this->displayTypeSelection($option_selection);
			} else {
				$this->cspDisplayError(__('There is some error in option selection.', 'customer-specific-pricing-for-woocommerce'));
			}

			die();
		}

		/**
		 * Gets the rule-type selected.
		 * For that option:
		 * Gets the display names for the particular rule-type
		 * Displays the selection list in the Search By tab.
		 * If option not selected , display error.
		 */
		public function getSearchSelectionCallback()
		{
			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_get_search_selection_user_capability', 'manage_options');

			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_select = apply_filters('csp_can_user_get_search_selection', current_user_can($capability_required));
			if (!$can_user_select) {
				echo 'Security Check';
				exit;
			}

			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			$option_selection = isset($postArray['option_type']) ? $postArray['option_type'] : '';

			if (!empty($option_selection)) {
				$selection_list = $this->getSelectionList($option_selection);

				$this->displaySelectionList($selection_list, array(), false);
			} else {
				$this->cspDisplayError(__('There is some error in option selection.', 'customer-specific-pricing-for-woocommerce'));
			}

			die();
		}

		/**
		 * Displays Selection & Product List
		 * If the rule-type is group check if groups plugin is active
		 * otherwise give an error.
		 * Gets the selection list for the rule-type selected.
		 * Gets the full product list for selection.
		 * If for that selection already a rule exists, show edit button.
		 *
		 * @param  string $option_selection rule-type
		 * @param array $existing_selections associated-entities of subrules
		 * @param array $existing_products product-ids of subrule.
		 */
		public function displayTypeSelection($option_selection, $existing_selections = array(), $existing_products = array())
		{
			global $cspFunctions;
			if ('group' === $option_selection && !$cspFunctions->wdmIsActive('groups/groups.php')) {
				$cspFunctions->showGroupPluginDirectInstallLinks();
				die();
			}
?>
			<div class="csp-selection-wrapper wdm-clear">
				<?php

				$selection_list  = $this->getSelectionList($option_selection);

				$product_list    = $this->getProductList();

				$this->displaySelectionList($selection_list, $existing_selections);

				$this->displayProductList($product_list, $existing_products);

				if (!empty($selection_list) && !empty($product_list)) {
				?>

					<input type="button" class="btn btn-primary" id="wdm_csp_set_price" value="<?php echo esc_attr__('Set Prices', 'customer-specific-pricing-for-woocommerce'); ?>">
					<!-- Show edit button only if query_log parameter is set -->
					<?php if (isset($_GET['query_log'])) { ?>
						<input type="button" class="btn btn-primary" id="wdm_edit_entries" value="<?php esc_attr_e('Edit this rule', 'customer-specific-pricing-for-woocommerce'); ?>" />
						<input type="button" class="btn btn-primary" id="wdm_back" data-selected-feild="akshay" value="<?php esc_attr_e('Back', 'customer-specific-pricing-for-woocommerce'); ?>" />
					<?php
					}

					/**
					 * This action is being used for loading the Cart Discounts tab on content on the WP admin settings page,
					 * The same hook can be used to add functionality/html above or under the page.  
					 * 
					 * @since 4.3.0
					 */
					do_action('wdm_after_product_selection');
					?>
					<div class="wdm-csp-product-details-list"></div>
				<?php
				}
				?>
			</div>
		<?php
		}

		//function ends -- displayTypeSelection

		/**
		 * Displays the error strings.
		 *
		 * @param string $error_string error string.
		 */
		public function cspDisplayError($error_string)
		{
		?>
			<div class="error">
				<p><?php echo wp_kses_post($error_string); ?> </p>
			</div>
			<?php
		}

		/**
		 * Return the rule-type selected
		 *
		 * @param string $optionType rule-type selected
		 * @return string rule-type.
		 */
		private function getOptionSelection($optionType)
		{
			if ('customer' == $optionType) {
				return __('customer', 'customer-specific-pricing-for-woocommerce');
			}
			if ('role' == $optionType) {
				return __('role', 'customer-specific-pricing-for-woocommerce');
			}
			if ('group' == $optionType) {
				return __('group', 'customer-specific-pricing-for-woocommerce');
			}
		}

		/**
		 * Displays the selection list in the Search By tab.
		 * Gets the rule-type selected.
		 * Gets the selections of the rule-type.
		 * Gets the existing selections of rule-type having the subrules.
		 * If selection list empty display error.
		 *
		 * @param array $selection_list  all Selections of rule-type.
		 * @param array $existing_selections existing selections of rule-type * in that subrule
		 * @param bool $default_option if accesed directly.
		 */
		private function displaySelectionList($selection_list, $existing_selections = array(), $default_option = false)
		{
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			if (isset($postArray['option_type'])) {
				$option_selection = $this->getOptionSelection($postArray['option_type']);
			} else {
				$option_selection = '';
			}

			if (isset($selection_list['value']) && is_array($selection_list['value'])) {
				if (isset($postArray['single_view_action']) &&  'search' == $postArray['single_view_action']) {
					$this->printSearchDropdown($option_selection, $default_option, $selection_list, $existing_selections);
				} else {
					$this->printSelectionDropdown($option_selection, $default_option, $selection_list, $existing_selections);
				}
			?>

			<?php
			} else {
				$this->cspDisplayError(__('Selection List empty.', 'customer-specific-pricing-for-woocommerce'));
			}
		}

		/**
		 * Display the existing selections display names for the rule-type
		 * selected in a drop-down.
		 *
		 * @param string $option_selection rule-type selected.
		 * @param bool $default_option if accesed directly.
		 * @param array $selection_list all Selections of rule-type.
		 * @param array $existing_selections existing selections of rule-type * in that subrule
		 *
		 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
		 */
		private function printSelectionDropdown($option_selection, $default_option, $selection_list, $existing_selections)
		{
			?>
			<div class="csp-selection-list-wrapper">
				<div class="form-group row">
					<label class="wdm-csp-single-view-section-heading col-md-2 form-control-label">
						<?php echo esc_html(isset($selection_list['label']) ? $selection_list['label'] : ''); ?>
					</label>
					<div class="col-md-4 form-control-wrap form-control-wrap-alt">
						<select name='wdm_selections' class="form-control wdm-csp-single-view-form-control" id="selected-list_wdm_selections" multiple>
							<?php
							foreach ($selection_list['value'] as $key => $value) {
							?>
								<option value="<?php echo esc_attr($key); ?>" <?php
																				if (in_array($key, $existing_selections)) {
																					echo 'selected="selected"';
																				}
																				?>><?php echo esc_html($value); ?></option>
							<?php
							} //foreach ends
							?>
						</select>
					</div>
				</div>
			</div>
		<?php
		}

		/**
		 * Display the selections display names for the rule-type selected in * a drop-down.
		 *
		 * @param string $option_selection rule-type selected.
		 * @param bool $default_option if accesed directly.
		 * @param array $selection_list all Selections of rule-type.
		 * @param array $existing_selections existing selections of rule-type * in that subrule
		 */
		private function printSearchDropdown($option_selection, $default_option, $selection_list, $existing_selections)
		{
		?>
			<div class="csp-selection-list-wrapper">
				<div class="form-group row">
					<label class="wdm-csp-single-view-section-heading col-md-2 form-control-label select-entity-type">
						<?php echo esc_html(isset($selection_list['label']) ? $selection_list['label'] : ''); ?>
					</label>
					<div class="col-md-4 form-control-wrap form-control-wrap-alt">
						<select name='wdm_selections' class="form-control wdm-csp-single-view-form-control" id="selected-list_wdm_selections">
							<option value="-1"><?php echo esc_html__('--Select--', 'customer-specific-pricing-for-woocommerce'); ?></option>
							<?php
							if (false !== $default_option) {
							?>
								<option value="-1"><?php __('Select', 'customer-specific-pricing-for-woocommerce') . ' ' . $default_option; ?></option>
							<?php
							}
							foreach ($selection_list['value'] as $key => $value) {
							?>
								<option value="<?php echo esc_attr($key); ?>" <?php
																				if (in_array($key, $existing_selections)) {
																					echo 'selected="selected"';
																				}
																				?>><?php echo esc_html($value); ?></option>
							<?php
							} //foreach ends
							?>
						</select>
					</div>
				</div>
			</div>
			<?php
		}

		/**
		 * For Product-Pricing tab gets the Products list.
		 * If no products added , display error.
		 *
		 * @param array $product_list all products in database.
		 * @param array $existing_products existing products for that
		 * subrule,initially empty.
		 */
		private function displayProductList($product_list, $existing_products = array())
		{
			if (!empty($product_list)) {
			?>
				<div class="csp-product-list csp-selection-wrapper-sections">
					<div class="form-group row">
						<label class="wdm-csp-single-view-section-heading col-md-2 form-control-label"><?php echo esc_html__('Select Product', 'customer-specific-pricing-for-woocommerce'); ?></label>
						<div class="col-md-4 form-control-wrap form-control-wrap-alt">
							<select name='wdm_product_lists' id='wdm_product_lists' multiple class="form-control wdm-csp-single-view-form-control">
								<?php
								foreach ($product_list as $product_id => $product_name) {
								?>
									<option value="<?php echo esc_attr($product_id); ?>" <?php
																							if (in_array($product_id, $existing_products)) {
																								echo 'selected="selected"';
																							}
																							?>><?php echo esc_html($product_name); ?></option>
								<?php
								}
								?>
							</select>
						</div>
					</div>
				<?php
			} else {
				$this->cspDisplayError(__('Please add Products.', 'customer-specific-pricing-for-woocommerce'));
			}
		}

		/**
		 * Gets the display names for the particular rule-type
		 * If the result is empty, or there are no such names for that
		 * rule-type, show the label for selection.
		 * Returns the array of names associated with id.
		 *
		 * @param string $option_type rule-type
		 * @return array $selection_list id and display names of rule-type.
		 */
		private function getSelectionList($option_type)
		{

			$option_type = trim(strtolower($option_type));
			global $wpdb, $cspFunctions;


			if ('group' === $option_type && !$cspFunctions->wdmIsActive('groups/groups.php')) {
				$this->cspDisplayError(__("Activate the 'Groups' Plugin to enjoy the benefits of Group Specific Pricing.", 'customer-specific-pricing-for-woocommerce'));
				die();
			}

			$selection_list = array();

			if (!empty($option_type)) {
				if ('customer' === $option_type) {
					$user_list = $cspFunctions->getSiteUserIdNamePairs();

					if (!empty($user_list)) {
						$selection_list['label'] = __('Customer', 'customer-specific-pricing-for-woocommerce');

						foreach ($user_list as $single_user) {
							$selection_list['value'][$single_user->id] = $single_user->user_login;
						} //foreach ends --loop through user list
					} //if ends -- User list not empty
				} elseif ('role' === $option_type) {
					$editable_roles = array_reverse(get_editable_roles());

					if (!empty($editable_roles)) {
						$selection_list['label'] = __('Role', 'customer-specific-pricing-for-woocommerce');

						foreach ($editable_roles as $role => $details) {
							$name                                = translate_user_role($details['name']);
							$selection_list['value'][$role]  = $name;
						} //foreach ends
					} //if ends -- editable rows not empty
				} elseif ('group' === $option_type) {

					$get_group_details = $wpdb->get_results('SELECT  group_id ,  name
					FROM  ' . $wpdb->prefix . 'groups_group
					Order By name');

					if (!empty($get_group_details)) {
						$selection_list['label'] = __('Groups', 'customer-specific-pricing-for-woocommerce');

						foreach ($get_group_details as $single_group) {
							$selection_list['value'][$single_group->group_id] = $single_group->name;
						}
					}
				}
			} //if ends -- option_type not empty
			return $selection_list;
		}

		//function ends -- getSelectionList

		/**
		 * Gets all the posts which are products.
		 * Gets the array with key as product-id and value as name.
		 * For variable products key is variation-id and value is
		 * variation-attributes
		 *
		 * @return array $full_product_list Product list
		 */
		private function getProductList()
		{
			global $wpdb;
			$parentVariations = array();
			$parentVariationNames = array();
			$full_product_list = array();

			$productsList   = $wpdb->get_results('SELECT ID, post_title FROM ' . $wpdb->prefix . 'posts where post_type="product" AND post_status IN ("draft", "publish", "pending")');

			// This will fetch post title and post excerpt
			$variantsList   = $wpdb->get_results('SELECT ID, post_title, post_excerpt , post_parent FROM ' . $wpdb->prefix . 'posts where post_type="product_variation" AND post_status IN ("private", "publish", "pending")');

			if ($variantsList) {
				foreach ($variantsList as $variant) {
					$parent = $variant->post_parent;
					if (!in_array($parent, $parentVariations)) {
						$parentVariations[] = $parent;
					}
				}
			}

			if ($productsList) {
				foreach ($productsList as $singleProduct) {
					$product_id = $singleProduct->ID;
					if (!empty($parentVariations) && in_array($product_id, $parentVariations)) {
						$parentVariationNames[$product_id] = $singleProduct->post_title;
					} else {
						$full_product_list[$product_id] = $singleProduct->post_title;
					}
				}
				// exit;
			} //posts end

			//  This will show variable name instead of variable_id of variable product.
			if ($variantsList) {
				foreach ($variantsList as $variant) {
					//$variableProduct=wc_get_product($variant->ID);
					//$attributes=$variableProduct->attributes;
					if (str_contains($variant->post_title, '-')) {
						$char_position = strpos($variant->post_title, '-');
						$substrings_title = substr($variant->post_title, 0, $char_position + 1);
						$full_product_list[$variant->ID] = $substrings_title . ' ' . $variant->post_excerpt;
					} else {
						$full_product_list[$variant->ID] = $variant->post_title . ': ' . $variant->post_excerpt;
					}
				}
			}
			// sort into alphabetical order, by title
			asort($full_product_list);

			/**
			 * Filter to alter the full product list.
			 *
			 * @param array Array containing all the posts which are products.
			 *              For simple products, the array contains key as product-id and value as name.
			 *              For variable products, key is variation-id and value is
			 * variation-attribute.
			 */
			return apply_filters('wdm_csp_filter_product_pricing_product_list', $full_product_list);
		}

		/**
		 * Checks the capability of the user.
		 * Gets the products titles for selection.
		 * Gets the specific pricing details array for the products.
		 * Gets the query log for rules page.
		 * Returns the array containing above three parameters as values
		 * Displays error if there is no selection.
		 */
		public function getProductPriceListCallback()
		{
			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_get_product_price_list_user_capability', 'manage_options');

			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_select = apply_filters('csp_can_user_get_product_price_list', current_user_can($capability_required));
			if (!$can_user_select) {
				echo 'Security Check';
				exit;
			}
			$selection_list = '';
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			if (isset($postArray['selection_list'])) {
				$selection_list = $postArray['selection_list'];
			}

			$product_list = '';
			if (isset($postArray['product_list'])) {
				$product_list = $postArray['product_list'];
			}
			$option_type = '';
			if (isset($postArray['option_type'])) {
				$option_type = $postArray['option_type'];
			}

			if (!empty($selection_list) && !empty($product_list) && !empty($option_type)) {
				//Process the details

				$product_result['title_name'] = $this->getProductDetailTitles($option_type);

				$product_result['value'] = $this->getProductDetailList($option_type, $product_list, $selection_list);

				$product_result['query_input'] = $this->getQueryInput();
				echo json_encode($product_result);
			} else {
				$this->cspDisplayError(__('Some details are not found.', 'customer-specific-pricing-for-woocommerce'));
			}
			die();
		}

		/**
		 * Returns the specific pricing details array for the products.
		 * Prepare the details of subrules in array format.
		 *
		 * @param string $option_selected rule-type selected.
		 * @param array $product_list Product tiles
		 * @param array $selection_values selected rule-type names
		 * @param array $subruleInfo all subrules for the rule.
		 * @return array $product_detail_list pricing details for the products
		 */
		public function getProductDetailList($option_selected, $product_list, $selection_values, $subruleInfo = array())
		{

			$query_log_details   = array();

			if (!empty($subruleInfo)) {
				foreach ($subruleInfo as $singleRule) {
					if (!isset($query_log_details[$singleRule['product_id'] . '_' . $singleRule['associated_entity']])) {
						$query_log_details[$singleRule['product_id'] . '_' . $singleRule['associated_entity']]['action'] = ('2' == $singleRule['flat_or_discount_price']) ? '2' : '1';
						$query_log_details[$singleRule['product_id'] . '_' . $singleRule['associated_entity']]['value'] = $singleRule['price'];
						$query_log_details[$singleRule['product_id'] . '_' . $singleRule['associated_entity']]['min_qty'] = $singleRule['min_qty'];
					}
				}
			}
			$product_detail_list = $this->getProductPriceMapping($option_selected, $product_list, $selection_values, $query_log_details);
			/**
			 * This filter can be used to filter the list of subrules for the product pricing rule.
			 * 
			 * @param array $product_detail_list list of csp products rules.
			 */
			return apply_filters('csp_single_view_product_list', $product_detail_list);
		}

		/**
		 * Gets the Product specific price mapping list.
		 * Returns the specific pricing details array for the products.
		 *
		 * @param string $option_selected rule-type selected.
		 * @param array $product_list Product titles
		 * @param array $selection_values selected rule-type names
		 * @param array $query_log_details all subrules details entity wise.
		 * @return array $product_detail_list pricing details for the products
		 *
		 * @SuppressWarnings(PHPMD.UnusedLocalVariable)
		 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
		 */
		public function getProductPriceMapping($option_selected, $product_list, $selection_values, $query_log_details)
		{
			$discountOptions = array('1' => __('Flat', 'customer-specific-pricing-for-woocommerce'), '2' => '%');
			$product_detail_list = array();
			$value = '';
			$minQty = '';

			foreach ($selection_values as $SingleUser => $SingleName) {
				$userId = $SingleUser;
				foreach ($product_list as $product_id => $product_name) {
					$qtyFlag = false;

					$regular_price   = $this->wdmGetPriceForProductPricingTable(get_post_meta($product_id, '_regular_price', true));
					$sale_price      = $this->wdmGetPriceForProductPricingTable(get_post_meta($product_id, '_sale_price', true));

					$existing_qty       = 1;
					$existing_value     = '';
					$existing_action    = '';

					// Decimal Quantity Fields
					$wdm_WooDecimalProduct_Min_Quantity_Default    = get_option('woodecimalproduct_min_qnt_default', 1.0);
					$wdm_WooDecimalProduct_Step_Quantity_Default   = get_option('woodecimalproduct_step_qnt_default', 1.0);
					$wdm_WooDecimalProduct_Item_Quantity_Default   = get_option('woodecimalproduct_item_qnt_default', 1.0);
					$wdm_WooDecimalProduct_Max_Quantity_Default    = get_option('woodecimalproduct_max_qnt_default', '');

					if (isset($query_log_details[$product_id . '_' . $userId]['value'])) {
						$existing_value = wc_format_localized_price(wc_format_decimal($query_log_details[$product_id . '_' . $userId]['value'], '', true));
					}
					if (isset($query_log_details[$product_id . '_' . $userId]['min_qty'])) {
						$existing_qty = $query_log_details[$product_id . '_' . $userId]['min_qty'];
					}
					if (isset($query_log_details[$product_id . '_' . $userId]['action'])) {
						$existing_action = $query_log_details[$product_id . '_' . $userId]['action'];
					}

					$minQty = '<input type="number" min = "' . esc_attr($wdm_WooDecimalProduct_Min_Quantity_Default) . '" step = "' . esc_attr($wdm_WooDecimalProduct_Step_Quantity_Default) . '" value="' . esc_attr($existing_qty) . '" placeholder="1" name="csp_qty_' . esc_attr($product_id) . '_' . esc_attr($userId) . '" id="csp_qty" class="csp_single_view_qty" data-oldval = "' . esc_attr($existing_qty) . '" step="1"/>';
					if ('2' == $existing_action) {
						if ('%' == $discountOptions[$existing_action]) {
							$value = '<input type="text" value="' . esc_attr($existing_value) . '" placeholder="0" name="csp_value_' . esc_attr($product_id) . '_' . esc_attr($userId) . '" id="csp_value" class="csp_single_view_value csp-percent-discount" />';
						}
					} else {
						$value = '<input type="text" value="' . esc_attr($existing_value) . '" placeholder="0" name="csp_value_' . esc_attr($product_id) . '_' . esc_attr($userId) . '" id="csp_value" class="csp_single_view_value" value="' . esc_attr($existing_value) . '"/>';
					}

					$action = '<select name="wdm_csp_price_type' . esc_attr($product_id) . '_' . esc_attr($userId) . '" class="chosen-select csp_single_view_action">';

					foreach ($discountOptions as $k => $val) {
						if ($existing_action == $k) {
							$action .= '<option value = "' . esc_attr($k) . '" selected>' . esc_html($discountOptions[$k]) . '</option>';
						} else {
							$action .= '<option value = "' . esc_attr($k) . '">' . esc_html($discountOptions[$k]) . '</option>';
						}
						unset($val);
					}
					$action			.= '</select>';
					$productEditLink = get_permalink($product_id);
					$productLink	 = '<a href="' . esc_url($productEditLink) . '" target="_blank">' . esc_html($product_id) . '</a>';
					$product_detail_list[] = array($productLink, $product_name, $SingleName, $regular_price, $sale_price, $action, $minQty, $value);
				}                # code...
			}
			/**
			 * This filter can be used to filter the list of subrules for the product pricing rule.
			 * 
			 * @param array $product_detail_list List of CSP product rules.
			 */
			return apply_filters('csp_single_view_product_price_mapping', $product_detail_list);
		}





		/**
		 * Returns Float value if $value is not empty
		 * Returns "--" when value is not empty.
		 *
		 * @param [type] $value
		 * @return mixed
		 */
		private function wdmGetPriceForProductPricingTable($value)
		{
			if (!empty($value)) {
				$value = floatval($value);
			} else {
				$value = '--';
			}
			return $value;
		}

		/**
		 * Gets the Product Details titles
		 *
		 * @param string $option_type rule-type.
		 * @return array $titles titles for Product details
		 */
		public function getProductDetailTitles($option_type)
		{
			$tableOptionTypes    = array(
				'role'       => __('Role', 'customer-specific-pricing-for-woocommerce'),
				'group'      => __('Group', 'customer-specific-pricing-for-woocommerce'),
				'customer'   => __('Customer', 'customer-specific-pricing-for-woocommerce'),
			);
			$titles              = array(
				array('title' => __('Product ID', 'customer-specific-pricing-for-woocommerce')),
				array('title' => __('Product Name', 'customer-specific-pricing-for-woocommerce')),
				array('title' => $tableOptionTypes[$option_type]),
				array('title' => __('Regular Price', 'customer-specific-pricing-for-woocommerce')),
				array('title' => __('Sale Price', 'customer-specific-pricing-for-woocommerce')),
				array('title' => __('Flat or Discounts', 'customer-specific-pricing-for-woocommerce')),
				array('title' => __('Min Qty', 'customer-specific-pricing-for-woocommerce')),
				array('title' => __('Value', 'customer-specific-pricing-for-woocommerce')),
			);

			/**
			 * Filter the titles for the product price list table.
			 * 
			 * @param array $titles array of titles.
			 */
			return apply_filters('csp_single_view_table_titles', $titles);
		}

		/**
		 * On the Rules page for new rule or edit rule.
		 * Display the templates for the buttons.
		 *
		 * @param string $query_title rule-title
		 * @return string HTML for the Rules page.
		 */
		public function getQueryInput($query_title = '')
		{
			ob_start();
				?>
				<div class="row form-group">
					<label class="col-md-2 form-control-label"><?php esc_html_e('Rule Title', 'customer-specific-pricing-for-woocommerce'); ?>
						<span class="wdm-required">*</span>
						<a class="wdm_wrapper">
							<img class="help_tip" src="<?php echo esc_url(plugins_url('/images/help.png', dirname(__FILE__))); ?>" height="20" width="20">
							<span class='wdm-tooltip-content'>
								<span class="wdm-tooltip-text">
									<span class="wdm-tooltip-inner">
										<?php esc_html_e('Rule title will help identify the rules generated for Users/Roles/Groups.', 'customer-specific-pricing-for-woocommerce'); ?>
									</span>
								</span>
							</span>
						</a>
					</label>
					<div class="col-md-4 form-control-wrap">
						<input type="text" name="wdm_csp_query_title" id="wdm_csp_query_title" size="80" value="<?php echo esc_attr($query_title); ?>" class="form-control" />
						</span>
						<input type="hidden" name="wdm_csp_query_time" id="wdm_csp_query_time" value="<?php echo esc_attr(get_current_user_id() . '_' . time()); ?>">
					</div>
				</div>
				<input type="button" class="btn btn-primary" id="wdm_csp_save_changes" value="<?php echo isset($_GET['query_log']) ? esc_attr__('Update Rule', 'customer-specific-pricing-for-woocommerce') : esc_attr__('Save Rule', 'customer-specific-pricing-for-woocommerce'); ?>">

				<div class="progress progress-striped">
					<div class="progress-bar six-sec-ease-in-out" role="progressbar" data-transitiongoal="0"></div>
				</div>
				<p class="csp-log-progress"></p>
	<?php
			$result = ob_get_contents();

			ob_end_clean();

			return $result;
		}

		/**
		 * Check the capability for user.
		 * Take the product pricing from the rules and updates in the DB.
		 * Save the new pricing pairs in database.
		 */
		public function saveQueryLogCallback()
		{
			global $cspFunctions;

			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_save_query_log_user_capability', 'manage_options');

			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_save = apply_filters('csp_can_user_save_query_log', current_user_can($capability_required));
			if (!$can_user_save) {
				echo 'Security Check';
				exit;
			}
			$wdm_save_result = '';

			$default_values = array(
				'option_type' => '',
				'selection_list' => '',
				'product_values' => '',
				'product_actions' => '',
				'product_quantities' => '',
				'productOldQuantities' => '',
				'query_title' => '',
				'option_name' => '',
				'current_query_id' => ''
			);
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$wdm_data_array = array_filter(array(
				'option_type'          => $postArray['option_type'],
				'selection_list'       => $postArray['selection_list'],
				'product_values'       => $postArray['product_values'],
				'product_actions'      => $postArray['product_actions'],
				'product_quantities'   => $postArray['product_quantities'],
				'productOldQuantities' => $postArray['productOldQuantities'],
				'query_title'          => $postArray['query_title'],
				'option_name'          => $postArray['option_name'],
				'current_query_id'     => isset($postArray['current_query_id']) ? $postArray['current_query_id'] : ''
			));

			$wdm_parsed_values = wp_parse_args($wdm_data_array, $default_values);

			$selection_list = trim($wdm_parsed_values['selection_list'], ',');

			$option_type = $wdm_parsed_values['option_type'];

			$values  = array();
			$quantities = array();
			$oldQuantities = array();
			$actions = array();

			parse_str($wdm_parsed_values['product_values'], $values);
			parse_str($wdm_parsed_values['product_quantities'], $quantities);
			parse_str($wdm_parsed_values['productOldQuantities'], $oldQuantities);
			parse_str($wdm_parsed_values['product_actions'], $actions);
			if ('customer' === $option_type) {
				$wdm_save_result = $cspFunctions->saveCustomerPricingPair(explode(',', $selection_list), $values, $quantities, $oldQuantities, $actions, $wdm_parsed_values['query_title'], $wdm_parsed_values['option_name'], $wdm_parsed_values['current_query_id']);
			} elseif ('role' === $option_type) {
				$wdm_save_result = $cspFunctions->saveRolePricingPair(explode(',', $selection_list), $values, $quantities, $oldQuantities, $actions, $wdm_parsed_values['query_title'], $wdm_parsed_values['option_name'], $wdm_parsed_values['current_query_id']);
			} elseif ('group' === $option_type) {
				$wdm_save_result = $cspFunctions->saveGroupPricingPair(explode(',', $selection_list), $values, $quantities, $oldQuantities, $actions, $wdm_parsed_values['query_title'], $wdm_parsed_values['option_name'], $wdm_parsed_values['current_query_id']);
			}

			echo json_encode($wdm_save_result);

			die();
		}

		/**
		 * Gets the Progress Status from the options table.
		 */
		public function getProgressStatusCallback()
		{
			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_get_progress_status_user_capability', 'manage_options');

			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_get_status = apply_filters('csp_can_user_get_progress_status', current_user_can($capability_required));
			if (!$can_user_get_status) {
				echo 'Security Check';
				exit;
			}

			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$option_name = isset($postArray['option_name']) ? $postArray['option_name'] : '';
			$result      = array('value' => 0, 'status' => '');

			if (!empty($option_name)) {
				$result['value']   = get_option($option_name . '_value', 0);
				$result['status']  = get_option($option_name . '_status', '');
			}

			echo json_encode($result);
			die();
		}

		/**
		 * If the user can access the backend.
		 * Get the selections for the customer/group/role specific pricing
		 * pairs.
		 * Get the pricing pairs for the entities when accesed directly, or
		 * by rules.
		 * Display the selection list for various entities pricings
		 */
		public function displayProductPricesCallback()
		{
			global $cspFunctions;
			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_display_product_price_user_capability', 'manage_options');

			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_display    = apply_filters('csp_can_user_display_product_price', current_user_can($capability_required));
			if (!$can_user_display) {
				echo 'Security Check';
				exit;
			}

			$postArray 	    	 = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$option_type    	 = isset($postArray['option_type']) ? $postArray['option_type'] : '';
			$selection_name 	 = isset($postArray['selection_name']) ? $postArray['selection_name'] : '';
			$selection_list 	 = array();
			$product_list   	 = array();
			$group_plugin_active = $cspFunctions->wdmIsActive('groups/groups.php');

			if ('customer' === $option_type) {
				$user_id = intval($selection_name);
				$this->saveRecentSearches($user_id);
				$selection_list = $this->getSelectionCustomer($user_id, true);
				if (!empty($selection_list)) {
					$product_list = array_keys($selection_list);
				}
				$selection_list = $selection_list + $this->getSelectionCustomerDirect($user_id, $product_list, true);

				$selection_list = $cspFunctions->msort($selection_list, 'min_qty');

				$user_info = get_userdata($user_id);

				$product_list    = $product_list + array_keys($selection_list);

				$selection_list  = $selection_list + $this->getSelectionRole($user_info->roles, $product_list, true);

				$product_list    = $product_list + array_keys($selection_list);
				$selection_list  = $selection_list + $this->getSelectionRoleDirect($user_info->roles, $product_list, true);

				if ($group_plugin_active) {
					$product_list = array_keys($selection_list);
					$groups_user = new \Groups_User(intval($selection_name));

					// get group ids (user is direct member)
					$user_group_ids = $groups_user->group_ids;

					$product_list    = $product_list + array_keys($selection_list);
					$selection_list  = $selection_list + $this->getSelectionGroup($user_group_ids, $product_list, true);

					$product_list    = $product_list + array_keys($selection_list);
					$selection_list  = $selection_list + $this->getSelectionGroupDirect($user_group_ids, $product_list, true);
				}
			} elseif ('role' === $option_type) {
				$selection_list = $this->getSelectionRole(array($selection_name), array(), true);
				if (!empty($selection_list)) {
					$product_list = array_keys($selection_list);
				}
				$selection_list = $selection_list + $this->getSelectionRoleDirect(array($selection_name), $product_list, true);
			} elseif ('group' === $option_type && $group_plugin_active) {
				$selection_list = $this->getSelectionGroup(array($selection_name), array(), true);
				if (!empty($selection_list)) {
					$product_list = array_keys($selection_list);
				}

				$selection_list = $selection_list + $this->getSelectionGroupDirect(array($selection_name), $product_list, true);
			}
			//Print selection
			$selection_list = $cspFunctions->msort($selection_list, 'min_qty');

			echo json_encode($this->displaySelections($selection_list));
			die();
		}

		/**
		 * Returns the display list with the various parameters of the
		 * entities specific pricing.
		 * If selection list is empty gives an error.
		 *
		 * @param array $selection_list array of pricing selections for
		 * various entities.
		 *
		 * @SuppressWarnings(PHPMD.UnusedLocalVariable)
		 */
		private function displaySelections($selection_list)
		{
			$display_list = array();

			if (!empty($selection_list)) {
				foreach ($selection_list as $id => $selection_detail) {
					$product_id = $selection_detail['product_id'];
					if (get_post_type($product_id) == 'product_variation') {
						$parent_id           = wp_get_post_parent_id($product_id);
						$product_title       = get_the_title($parent_id);
						$variable_product    = new \WC_Product_Variation($product_id);
						$attributes          = $variable_product->get_variation_attributes();
						//get all attributes name associated witj this variation
						$attribute_names = array_keys($variable_product->get_attributes());

						$pos = 0; //Counter for the position of empty attribute
						foreach ($attributes as $key => $value) {
							if (empty($value)) {
								$attributes[$key] = 'Any ' . $attribute_names[$pos++];
							}
						}

						$product_title .= '-->' . implode(', ', $attributes);
					} else {
						$product_title = get_the_title($product_id);
					}
					$productLink 		       = get_permalink($product_id);
					$product_title			   = '<a href="' . $productLink . '" target="_blank">' . $product_title . '</a>';
					$regularPrice		 	   = wc_format_decimal($selection_detail['regular_price'], null, true);
					$selection_detail['price'] = number_format($selection_detail['price'], wc_get_price_decimals());
					$selection_detail_price = wc_format_localized_price($selection_detail['price']);
					$selectionCb = '<input class="wdm-csp-sel-cb" type="checkbox">';
					$selDetailQueryTitle = $selection_detail['query_title'];
					/**
					 * It contains 'Role' or 'Group' if CSP pricing is 'role
					 * specific' or 'group specific' respectively. If the
					 * pricing is neither 'role specific' nor 'group specific',
					 * then it contains 'Customer' as string.
					 *
					 * @var string
					 */
					$roleGroupCSP = 'Customer';
					$ruleNo       = $selection_detail['query_id'];

					$queryTitleForSourceColumn = strstr($selDetailQueryTitle, '-wdm-csp', true);
					$queryTitleForTrashSource  = strstr($selDetailQueryTitle, 'wdm-csp');

					// If the 'title' is 'Direct', then '$queryTitleForSourceColumn'
					// and '$queryTitleForTrashSource' would be empty.
					if (empty($queryTitleForSourceColumn)) {
						$queryTitleForSourceColumn = $selDetailQueryTitle;
						$queryTitleForTrashSource  = $selDetailQueryTitle;
					}

					$postArray 	    	 = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
					$selection_name 	 = isset($postArray['selection_name']) ? $postArray['selection_name'] : '';
					$queryTitleForTrashSource = ('Direct' == $selDetailQueryTitle) ? 'Direct-' . intval($selection_name) : $queryTitleForTrashSource;

					if ('--' == $ruleNo) {
						if (strpos($queryTitleForTrashSource, 'wdm-csp-role') !== false) {
							$roleGroupCSP = 'Role';
						} elseif (strpos($queryTitleForTrashSource, 'wdm-csp-group') !== false) {
							$roleGroupCSP = 'Group';
						}
					} else {
						global $ruleManager;
						$roleGroupCSP = $ruleManager->getRuleType($ruleNo);
					}

					$selectionMinQty    = $selection_detail['min_qty'];
					$selectionPriceType = $selection_detail['price_type'];
					$selectionRuleNo    = $selection_detail['query_id'];
					$removeButton 		= "<a class='wdm-csp-rm-record'
                                        data-product-id = $product_id
                                        data-min-qty    = $selectionMinQty
                                        data-act-price  = $selection_detail_price
                                        data-dis-type   = $selectionPriceType
                                        data-rule-no    = $selectionRuleNo
                                        data-source     = $queryTitleForTrashSource
                                        data-role-group = $roleGroupCSP
                                        >
                                        <span class='dashicons dashicons-trash'></span>
                                    </a>";
					if (strpos($selDetailQueryTitle, '-wdm-csp-cat') !== false) {
						$helpTipText = __('Unable to delete this product rule as it was assigned to a category-based product rule. Please make changes in the category pricing tab.', 'customer-specific-pricing-for-woocommerce');
						$selection_detail['query_id'] = 'category';
						$removeButton                   = '<a class="wdm-csp-rm-record wdm-csp-cat-record"><span class="csp-help-tip dashicons dashicons-trash" data-tip="' . $helpTipText . '"></span></a>';

						$selectionCb                    = '<div class="csp-help-tip" data-tip="' . $helpTipText . '"><input class="wdm-csp-sel-cb" type="checkbox" disabled></div>';
					}

					$display_list[] = array($selectionCb, $product_title, $regularPrice, $selection_detail['min_qty'], $selection_detail_price, $selection_detail['price_type'], $selection_detail['query_id'], stripcslashes($queryTitleForSourceColumn), $removeButton);
				}
				return $display_list;
			} else {
				return array('error' => '<div class="error">' . __('No details saved.', 'customer-specific-pricing-for-woocommerce') . '</div>');
			}
		}

		/**
		 * Process the data of subrule of that user.
		 * Prepare the data and form in a particular format.
		 * Calculate the discounted price if the price-type is %.
		 *
		 * @param array $res Subrules info for that user.
		 * @param string $source source (rule)
		 * @param bool   $addRuleType True if rule type needs to be added in the
		 *                            'query_title'.
		 * @return array $result formatted subrule data.
		 *
		 * @SuppressWarnings(PHPMD.UnusedLocalVariable)
		 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
		 */
		private function processResult($res, $source, $addRuleType = false)
		{
			global $wpdb, $ruleManager, $cspFunctions;

			$result = array();
			foreach ($res as $key) {
				$prod_name  = $wpdb->get_results(
					$wpdb->prepare(
						'select post_title FROM ' . $wpdb->prefix . 'posts where ID = %d',
						$key['product_id']
					),
					ARRAY_A
				);

				$result[$key['product_id'] . '_' . $key['min_qty']]['product_id']  = $key['product_id'];
				$result[$key['product_id'] . '_' . $key['min_qty']]['product_name']    = $prod_name[0]['post_title'];

				if ('rule' == $source) {
					$rule_title = $ruleManager->getRuleTitle($key['rule_id']);
					$result[$key['product_id'] . '_' . $key['min_qty']]['query_title']     = $rule_title['rule_title'];
					$result[$key['product_id'] . '_' . $key['min_qty']]['query_id']        = $key['rule_id'];
				} else {
					$result[$key['product_id'] . '_' . $key['min_qty']]['query_title']     = $key['source'];
					$result[$key['product_id'] . '_' . $key['min_qty']]['query_id']        = '--';
				}

				$regularPrice = floatval(get_post_meta($key['product_id'], '_regular_price', true));

				$result[$key['product_id'] . '_' . $key['min_qty']]['price_type']     = $key['price_type'];
				$result[$key['product_id'] . '_' . $key['min_qty']]['min_qty']        = $key['min_qty'];
				$result[$key['product_id'] . '_' . $key['min_qty']]['regular_price']  = !empty($regularPrice) ? $regularPrice : '';
				$result[$key['product_id'] . '_' . $key['min_qty']]['discount_value'] = $key['price'];
				if (2 == $key['price_type']) {
					$cspSettings = get_option('wdm_csp_settings');
					$salePriceDiscountEnabled = isset($cspSettings['enable_sale_price_discount']) && 'enable' == $cspSettings['enable_sale_price_discount'] ? true : false;
					$salePrice = $cspFunctions->wdmGetSalePrice($key['product_id']);
					if ($salePriceDiscountEnabled && $salePrice) {
						$currentPrice = floatval($salePrice);
					} else {
						$currentPrice = $regularPrice;
					}
					if ($currentPrice >= 0) {
						$result[$key['product_id'] . '_' . $key['min_qty']]['price'] = $currentPrice - (($key['price'] / 100) * $currentPrice);
					}
				} else {
					$result[$key['product_id'] . '_' . $key['min_qty']]['price']       = $key['price'];
				}
			}
			return $result;
		}

		/**
		 * Gets the quantity based pricing for that product for that user.
		 * Gets the specific pricing for every products for that user.
		 *
		 * @param int $user_id User Id.
		 * @param array $product_exclude Products already included.
		 * @return array subrule product details for the subrule.
		 */
		private function getSelectionCustomerDirect($user_id, $product_exclude = array(), $addKey = false)
		{
			global $wpdb, $getCatRecords, $cspFunctions;

			$source = __('Direct', 'customer-specific-pricing-for-woocommerce');
			$res = $wpdb->get_results($wpdb->prepare('SELECT product_id, price, flat_or_discount_price as price_type, min_qty, %s as "source" FROM ' . $wpdb->prefix . 'wusp_user_pricing_mapping WHERE user_id = %d order by product_id', $source, $user_id), ARRAY_A);

			$catPrice = $getCatRecords->getAllProductPricesByUser($user_id, $addKey);

			$mergedPrices = $cspFunctions->mergeProductCatPriceSearch($res, $catPrice);
			if (empty($mergedPrices)) {
				return array();
			}

			foreach ($mergedPrices as $key => $singleResult) {
				if (in_array($singleResult['product_id'] . '_' . $singleResult['min_qty'], $product_exclude)) {
					unset($mergedPrices[$key]);
				}
			}

			$resultDirectCustomer = $this->processResult($mergedPrices, 'direct');

			if (!empty($resultDirectCustomer)) {
				return $this->processSelectionResult($resultDirectCustomer);
			}

			return array();
		}


		// getSelectionCustomerDirect ends


		/**
		 * Gets the quantity based pricing for that product for that roles.
		 * Gets the specific pricing for every products for that roles.
		 *
		 * @param array $role_list Roles.
		 * @param array $product_exclude Products already included.
		 * @return array subrule product details for the subrule.
		 */
		private function getSelectionRoleDirect($role_list, $product_exclude = array(), $addKey = false)
		{
			global $wpdb, $getCatRecords, $cspFunctions;

			$source = __('Direct', 'customer-specific-pricing-for-woocommerce');
			$prepareArgs = array_merge((array) $source, (array) $role_list);
			$res = $wpdb->get_results($wpdb->prepare('SELECT product_id, price, flat_or_discount_price as price_type, min_qty, %s as "source" FROM ' . $wpdb->prefix . 'wusp_role_pricing_mapping WHERE role IN (' . implode(', ', array_fill(0, count($role_list), '%s')) . ') order by product_id', $prepareArgs), ARRAY_A);

			if ($addKey) {
				foreach ($res as $key => $value) {
					$res[$key]['source'] .= '-wdm-csp-role-' . $role_list[0];
				}
			}

			// getAllProductPricesByRoles
			$catPrice = $getCatRecords->getAllProductPricesByRoles($role_list);
			if ($addKey) {
				foreach ($catPrice as $key => $value) {
					foreach ($value as $qty => $cspDetails) {
						if ('Direct' == $cspDetails['source']) {
							$catPrice[$key][$qty]['source'] .= '-wdm-csp-role-' . $role_list[0];
						} else {
							$catPrice[$key][$qty]['source'] .= '-wdm-csp-cat';
						}
					}
				}
			}

			$mergedPrices = $cspFunctions->mergeProductCatPriceSearch($res, $catPrice);

			if (null == $mergedPrices) {
				return array();
			}


			foreach ($mergedPrices as $key => $singleResult) {
				if (in_array($singleResult['product_id'] . '_' . $singleResult['min_qty'], $product_exclude)) {
					unset($mergedPrices[$key]);
				}
			}

			$resultRoleDirect = $this->processResult($mergedPrices, 'direct');

			if (!empty($resultRoleDirect)) {
				return $this->processSelectionResult($resultRoleDirect);
			}

			return array();
		}

		// getSelectionRoleDirect


		/**
		 * Gets the quantity based pricing for that product for that group-ids
		 * Gets the specific pricing for every products for that group-ids.
		 *
		 * @param array $group_ids Group Ids. Pass array containing single group
		 *                         when '$add_key' is true.
		 * @param array $product_exclude Products already included.
		 * @param bool  $addKey True if 'wdm-csp-group-{group_id}' key needs
		 *                      to be added, or false otherwise.
		 * @return array subrule product details for the subrule.
		 */
		private function getSelectionGroupDirect($group_ids, $product_exclude = array(), $addKey = false)
		{
			global $wpdb, $getCatRecords, $cspFunctions;

			$source = __('Direct', 'customer-specific-pricing-for-woocommerce');
			$prepareArgs = array_merge((array) $source, (array) $group_ids);

			$res = $wpdb->get_results($wpdb->prepare('SELECT product_id, group_id, price, flat_or_discount_price as price_type, min_qty, %s as "source" FROM ' . $wpdb->prefix . 'wusp_group_product_price_mapping WHERE group_id IN (' . implode(', ', array_fill(0, count($group_ids), '%s')) . ') order by product_id', $prepareArgs), ARRAY_A);

			if ($addKey) {
				foreach ($res as $key => $value) {
					$res[$key]['source'] .= '-wdm-csp-group-' . $res[$key]['group_id'];
				}
			}

			$catPrice = $getCatRecords->getAllProductPricesByGroups($group_ids);
			if ($addKey) {
				foreach ($catPrice as $key => $value) {
					foreach ($value as $qty => $cspDetails) {
						if ('Direct' == $cspDetails['source']) {
							$catPrice[$key][$qty]['source'] .= '-wdm-csp-group-' . $group_ids[0];
						} else {
							$catPrice[$key][$qty]['source'] .= '-wdm-csp-cat';
						}
					}
				}
			}
			$mergedPrices = $cspFunctions->mergeProductCatPriceSearch($res, $catPrice);

			if (null == $mergedPrices) {
				return array();
			}

			foreach ($mergedPrices as $key => $singleResult) {
				if (in_array($singleResult['product_id'] . '_' . $singleResult['min_qty'], $product_exclude)) {
					unset($mergedPrices[$key]);
				}
			}


			$resultGroupDirect = $this->processResult($mergedPrices, 'direct');

			if (!empty($resultGroupDirect)) {
				return $this->processSelectionResult($resultGroupDirect);
			}

			return array();
		}

		/**
		 * For the user gets all the active subrules from the DB.
		 * Prepare the subrule data in proper format.
		 * Get the Product details of the selection.
		 *
		 * @param int $user_id User Id.
		 * @param bool $addKey  True if key needs to be added to idenify
		 *                      the source, false otherwise.
		 * @return array $product_details Selected products details for
		 * subrule.
		 *
		 * @SuppressWarnings(PHPMD.UnusedLocalVariable)
		 */
		private function getSelectionCustomer($user_id, $addKey = false)
		{
			global $subruleManager;

			$product_details = array();

			$res = $subruleManager->getAllActiveSubrulesInfoForUserRules($user_id);

			if (null == $res) {
				return array();
			}

			$resultCustomer = $this->processResult($res, 'rule');

			if ($addKey) {
				foreach ($resultCustomer as $key => $value) {
					$resultCustomer[$key]['query_title'] .= '-wdm-csp-rule-ae-' . $user_id;
				}
			}

			if (!empty($resultCustomer)) {
				return $this->processSelectionResult($resultCustomer);
			}

			return $product_details;
		}

		//getSelectionCustomer ends

		/**
		 * For the roles gets all the active subrules from the DB.
		 * Prepare the subrule data in proper format.
		 * Get the Product details of the selection.
		 *
		 * @param array $role_list Roles.
		 * @param array $product_exclude Products already included.
		 * @param bool $addKey  Add CSP key to identify the source.
		 * @return array $product_details Selected products details for
		 * subrule.
		 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
		 * @SuppressWarnings(PHPMD.UnusedLocalVariable)
		 */
		private function getSelectionRole($role_list, $product_exclude = array(), $addKey = false)
		{
			global $subruleManager;
			$product_details = array();
			$res             = $subruleManager->getAllActiveSubrulesInfoForRolesRule($role_list);

			if (null == $res) {
				return array();
			}

			foreach ($res as $key => $singleResult) {
				if (in_array($singleResult['product_id'] . '_' . $singleResult['min_qty'], $product_exclude)) {
					unset($res[$key]);
				}
			}

			$resultRole = $this->processResult($res, 'rule');

			if ($addKey) {
				foreach ($resultRole as $key => $value) {
					$resultRole[$key]['query_title'] .= '-wdm-csp-rule-ae-' . $role_list[0];
				}
			}

			if (!empty($resultRole)) {
				return $this->processSelectionResult($resultRole);
			}
			return $product_details;
		}

		// getSelectionRole ends

		/**
		 * For the groups gets all the active subrules from the DB.
		 * Prepare the subrule data in proper format.
		 * Get the Product details of the selection.
		 *
		 * @param array $user_group_ids Group-ids. Pass an array containing
		 *                              single group id when '$addKey' is true.
		 * @param array $product_exclude Products already included.
		 * @param bool $addKey  True if key needs to be added to idenify
		 *                       the source, false otherwise.
		 * @return array $product_details Selected products details for
		 * subrule.
		 *
		 * @SuppressWarnings(PHPMD.UnusedLocalVariable)
		 */
		private function getSelectionGroup($user_group_ids, $product_exclude = array(), $addKey = false)
		{
			global $subruleManager;
			$product_details = array();
			$res             = $subruleManager->getAllActiveSubrulesInfoForGroupsRule($user_group_ids);

			if (null == $res) {
				return array();
			}

			foreach ($res as $key => $singleResult) {
				if (in_array($singleResult['product_id'] . '_' . $singleResult['min_qty'], $product_exclude)) {
					unset($res[$key]);
				}
			}

			$resultGroup = $this->processResult($res, 'rule');

			if ($addKey) {
				foreach ($resultGroup as $key => $value) {
					$resultGroup[$key]['query_title'] .= '-wdm-csp-rule-ae-' . $user_group_ids[0];
				}
			}

			if (!empty($resultGroup)) {
				return $this->processSelectionResult($resultGroup);
			}
			return $product_details;
		}

		/**
		 * Process the selected products results in array for that subrule
		 * info.
		 *
		 * @param array $result subrule data.
		 * @return array $product_details Selected products details for
		 * subrule.
		 */
		private function processSelectionResult($result)
		{
			$product_details = array();

			foreach ($result as $product) {
				if (!in_array($product['product_id'] . '_' . $product['min_qty'], $product_details)) {
					if (is_null($product['query_id'])) {
						$product['query_id'] = '--';
					}

					if (is_null($product['query_title'])) {
						$product['query_title'] = __('Direct', 'customer-specific-pricing-for-woocommerce');
					}
					if (1 == $product['price_type']) {
						$product['price_type'] = __('Flat Price', 'customer-specific-pricing-for-woocommerce');
					} elseif (2 == $product['price_type']) {
						$product['price_type'] = wc_format_decimal($product['discount_value'], null, true) . '%';
					}

					$product_details[$product['product_id'] . '_' . $product['min_qty']] = array(
						'product_id'   => $product['product_id'],
						'product_name'  => $product['product_name'],
						'regular_price' => $product['regular_price'],
						'price'         => $product['price'],
						'price_type'    => $product['price_type'],
						'min_qty'       => $product['min_qty'],
						'query_id'      => $product['query_id'],
						'query_title'   => $product['query_title']
					);
				}
			}
			return $product_details;
		}

		/**
		 * When remove rule is clicked.
		 * Gets the rule-id and deletes the rule fromDB.
		 */
		public function removeQueryLogCallback()
		{
			global $ruleManager;
			/**
			 * Filter to set the user with which capability is allowed for the operation.
			 * 
			 * @param string $capability wordpress user capability
			 */
			$capability_required = apply_filters('csp_remove_query_log_user_capability', 'manage_options');

			/**
			 * This filter can be used to conditionally allow user to access the functionality.
			 * 
			 * @param bool $allowAccess wether to allow the access to the functionality or not. 
			 */
			$can_user_remove = apply_filters('csp_can_user_remove_query_log', current_user_can($capability_required));
			if (!$can_user_remove) {
				echo 'Security Check';
				exit;
			}

			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			$query_log_ids = $postArray['query_log_id'];

			if (!empty($query_log_ids)) {
				foreach ($query_log_ids as $single_qlog_id) {
					$ruleManager->deleteRule($single_qlog_id);
				}

				echo '<div class="updated wdm-qlog-notification settings-error notice is-dismissible"><p>' . esc_html__('Rule Deleted.', 'customer-specific-pricing-for-woocommerce') . '</p></div>';
			} else {
				echo '<div class="error wdm-qlog-notification"><p>' . esc_html__('Please select some Log', 'customer-specific-pricing-for-woocommerce') . '</p></div>';
			}

			die();
		}

		/**
		 * Ajax callback to remove the single CSP price record.
		 */
		public function removeSingleRecordCSPPrice()
		{
			global $cspFunctions;
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$optionType     = isset($postArray['option_type']) ? $postArray['option_type'] : '';
			$selectionName  = isset($postArray['selection_name']) ? $postArray['selection_name'] : '';

			$recordData     = $postArray['record_data'];
			$cspSource      = $recordData['csp_source'];
			$productId      = $recordData['product_id'];
			$minQty         = $recordData['min_qty'];
			$ruleId         = $recordData['rule_no'];

			// if ('--' != $ruleId) {
			//     global $ruleManager, $subruleManager;
			//     $ruleType = $ruleManager->getRuleType($ruleId);
			//     $associatedEnt = substr($cspSource, 16);
			//     $subruleManager->deleteSubruleByRecordData($ruleId, $productId, $ruleType, $associatedEnt, $minQty);
			//     $cspFunctions->deleteCSPPrice($cspSource, $productId, $minQty, $associatedEnt, $ruleType);
			// } else {
			//     $cspFunctions->deleteCSPPrice($cspSource, $productId, $minQty, $selectionName);
			// }
			$cspFunctions->evaluateAndRemoveCSPPrice($optionType, $selectionName, $recordData, $cspSource, $productId, $minQty, $ruleId);
			wp_die(1);
		}

		/**
		 * Ajax callback to remove the bulk CSP price records.
		 */
		public function removeBulkRecordCSPPrice()
		{
			global $cspFunctions;
			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$optionType     = $postArray['option_type'];
			$selectionName  = $postArray['selection_name'];
			$selectedRecords = $postArray['record_data'];

			foreach ($selectedRecords as $recordData) {
				$cspSource      = $recordData['csp_source'];
				$productId      = $recordData['product_id'];
				$minQty         = $recordData['min_qty'];
				$ruleId         = $recordData['rule_no'];

				$cspFunctions->evaluateAndRemoveCSPPrice($optionType, $selectionName, $recordData, $cspSource, $productId, $minQty, $ruleId);
			}
			wp_die(1);
		}
		//function ends -- removeQueryLogCallback


		/**
		 * Generates a csv report by merging all the report containing batches.
		 * * Verify the nonce
		 * * gets report directory, deletes the report result file if exists.
		 * * fetches paths of all the files in the reports directory.
		 * * merge all the report batch files using method joinFiles.
		 * * returns the download path for the merged report file.
		 *
		 * @since 4.3.0
		 * @return void
		 */
		public function generateAndDownloadReport()
		{
			$importNonce = isset($_REQUEST['_wp_import_nonce']) ? sanitize_text_field($_REQUEST['_wp_import_nonce']) : '';
			$nonceVerification = wp_verify_nonce($importNonce, 'import_nonce');

			/**
			 * Filter to override the nonce verification.
			 *
			 * @param int|false 1 if the nonce is valid and generated between 0-12 hours ago, 2 if the nonce is valid and generated between 12-24 hours ago. False if the nonce is invalid
			 */
			$nonceVerification = apply_filters('csp_import_nonce_verification', $nonceVerification);
			if (!$nonceVerification) {
				echo 'Security Check';
				exit;
			}

			$uploadDir = wp_upload_dir();
			$reportsDir     = $uploadDir['basedir'] . '/cspReports';
			$mergedReportFile   = $reportsDir . '/mergedReport.csv';
			if (file_exists($mergedReportFile)) {
				unlink($mergedReportFile);
			}

			$allBatches = glob($reportsDir . '/*.csv');
			$this->joinFiles($allBatches, $mergedReportFile);

			$reportFileUrl = $uploadDir['baseurl'] . '/cspReports/mergedReport.csv';
			echo esc_url($reportFileUrl);
			die();
		}


		/**
		 * JoinFiles method works as follows
		 * * Creates the result file on the path provided by $result parameter
		 * * Iterates each line in all the files mentioned in the array $files & writes it to the result file
		 *
		 * @since 4.3.0
		 * @param array $files
		 * @param string $result - path to the file which contains the merged batches.
		 * @return void
		 */
		private function joinFiles(array $files, $result)
		{
			if (!is_array($files)) {
				throw new Exception(' $files must be an array');
			}

			$mergedFile = fopen($result, 'w');

			foreach ($files as $file) {
				$singleFile = fopen($file, 'r');
				while (!feof($singleFile)) {
					fwrite($mergedFile, fgets($singleFile));
				}
				fclose($singleFile);
				unset($singleFile);
			}
			fclose($mergedFile);
			unset($mergedFile);
		}


		/**
		 * Ajax callback to change the status of the global discount feature.
		 *
		 * @since 4.5.0
		 * @return void
		 */
		public function setGlobalDiscountFeatureStatus()
		{
			if (empty($_POST['cd_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['cd_nonce']), 'wdm-csp-gd')) {
				echo 'Security Check';
				exit();
			}

			if (isset($_POST['featureStatus']) && in_array($_POST['featureStatus'], array('enable', 'disable'))) {
				$featureStatus = sanitize_text_field($_POST['featureStatus']);
				wp_send_json(update_option('wdm_csp_gd_status', $featureStatus));
			}
		}

		/**
		 * Ajax Callback to save the global discount rules.
		 *
		 * @since 4.5.0
		 * @return void
		 */
		public function saveGlobalDiscountRuleData()
		{
			if (empty($_POST['cd_nonce']) || !wp_verify_nonce(sanitize_text_field($_POST['cd_nonce']), 'wdm-csp-gd')) {
				echo 'Security Check';
				exit();
			}
			$postArray	= filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$uspRules 	= isset($postArray['usp_rules']) ? $postArray['usp_rules'] : array();
			$rspRules	= isset($postArray['rsp_rules']) ? $postArray['rsp_rules'] : array();
			$gspRules 	= isset($postArray['gsp_rules']) ? $postArray['gsp_rules'] : array();

			include_once CSP_PLUGIN_PATH . '/includes/global-discount/class-global-discount-data-store.php';
			$status = \cspGlobalDiscounts\WisdmGlobalDiscountDataStore::saveDiscountRules($uspRules, $rspRules, $gspRules);
			wp_send_json($status);
		}


		/**
		 * This function is the call back function for the ajax request 'create_csv_bulk'
		 * The method creates the CSP rule csv files for
		 * * Category Specific Pricing Rules
		 * * Global Discounts Pricing Rules
		 *
		 * @since 4.6.0
		 */
		public function wdmCreateCsvForBulkDiscounts()
		{
			$nonce              = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');
			/**
			 * This filter can be used to Override nonce verification for extending import functionality in
			 * any third party extension.
			 * 
			 * @param bool|string $name $nonce_verification nonce name or false to disable nonce verification
			 */
			$nonce_verification = apply_filters('csp_export_nonce_verification', $nonce_verification);
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			} else {
				/**
				 * Filter to set the user with which capability is allowed for the operation.
				 * 
				 * @param string $capability WordPress user capability
				 * */
				$capability         = apply_filters('csp_get_export_capability', 'manage_options');

				/**
				 * Filter to set the user with which capability is allowed for the operation.
				 * 
				 * @param string $capability WordPress user capability
				 * */
				$capabilityToExport = apply_filters('csp_export_allowed_user_capability', $capability);

				/**
				 * This filter can be used to conditionally allow user to access the functionality.
				 * 
				 * @param bool $allowAccess wether to allow the access to the functionality or not. 
				 * */
				$can_user_export    = apply_filters('csp_can_user_export_csv', current_user_can($capabilityToExport));
				if (!$can_user_export) {
					esc_html_e('You are not allowed to export', 'customer-specific-pricing-for-woocommerce');
					exit;
				}
			}

			$postArray      = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$exportRulesFor = isset($postArray['export_rules_for']) ? $postArray['export_rules_for'] : '';
			$ruleType		= isset($postArray['option_val']) ? $postArray['option_val'] : '';
			$result 		= array();

			if (!in_array($ruleType, array('User', 'Role', 'Group'), false)) {
				$result =  array('status' => 'failed', 'message' => esc_html__('Sorry, Rule type selection is invalid', 'customer-specific-pricing-for-woocommerce'));
			}
			if (!in_array($exportRulesFor, array('category', 'global'), false)) {
				$result =  array('status' => 'failed', 'message' => esc_html__('Sorry, Trying to export the rules for unspecified feature', 'customer-specific-pricing-for-woocommerce'));
			} else {
				switch ($exportRulesFor) {
					case 'category':
						include_once plugin_dir_path(CSP_PLUGIN_FILE) . 'includes/import-export/export/class-category-rule-export.php';
						if (class_exists('cspCategoryPricing\cspExport\CSPCategoryRuleExport')) {
							$result = \cspCategoryPricing\cspExport\CSPCategoryRuleExport::getExportFile($ruleType);
						}
						break;
					case 'global':
						include_once plugin_dir_path(CSP_PLUGIN_FILE) . 'includes/import-export/export/class-global-discounts-rule-export.php';
						if (class_exists('cspGlobalDiscounts\CSPGlobalDiscountsRuleExport')) {
							$result = \cspGlobalDiscounts\CSPGlobalDiscountsRuleExport::getExportFile($ruleType);
						}
						break;
					default:
						# code...
						break;
				}
			}
			wp_send_json($result);
		}

		/**
		 * Generates a CSV with the product Id & Product Names
		 * This CSV can be useful for the user for referance while
		 * creating rule file for import.
		 *
		 * @return void
		 */
		public function wdmCreateProductListCSV()
		{
			$nonce              = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');
			/**
			 * This filter can be used to Override nonce verification for extending import functionality in
			 * any third party extension.
			 * 
			 * @param bool|string $name $nonce_verification nonce name or false to disable nonce verification
			 */
			$nonce_verification = apply_filters('csp_export_nonce_verification', $nonce_verification);
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			} else {
				/**
				 * Filter to set the user with which capability is allowed for the operation.
				 * 
				 * @param string $capability WordPress user capability
				 * */
				$capability         = apply_filters('csp_get_export_capability', 'manage_options');
				/**
				 * Filter to set the user with which capability is allowed for the operation.
				 * 
				 * @param string $capability WordPress user capability
				 * */
				$capabilityToExport = apply_filters('csp_export_allowed_user_capability', $capability);
				/**
				 * This filter can be used to conditionally allow user to access the functionality.
				 * 
				 * @param bool $allowAccess wether to allow the access to the functionality or not. 
				 * */
				$can_user_export    = apply_filters('csp_can_user_export_csv', current_user_can($capabilityToExport));
				if (!$can_user_export) {
					esc_html_e('You are not allowed to export', 'customer-specific-pricing-for-woocommerce');
					exit;
				}
			}
			$csvHeadings = array('Product Id', 'Product Title');
			/**
			 * This filter can be used to filter the headings of the Export CSV file.
			 * 
			 * @param array $csvHeadings list of CSV headings
			 */
			$csvHeadings = apply_filters('wdm_csp_filter_product_list_headings', $csvHeadings);
			$productList = $this->wdmGetIdNamePairsForAllProducts();
			/**
			 * This can be used to filter the productId-productName pair list fetch to be used in the export file.
			 * 
			 * @param array $productList list of productId-productName pairs.
			 */
			$productList = apply_filters('wdm_csp_filter_product_list', $productList);
			$result      = '';
			if (!empty($productList)) {
				$uploadDir  = wp_upload_dir();
				$deleteFile = glob($uploadDir['basedir'] . '/csp-product-list.csv');
				if ($deleteFile) {
					foreach ($deleteFile as $file) {
						unlink($file);
					}
				}
				$output 	 = fopen($uploadDir['basedir'] . '/csp-product-list.csv', 'w');
				fputcsv($output, $csvHeadings);
				foreach ($productList as $row) {
					$array = (array) $row;
					fputcsv($output, $array);
				}
				fclose($output);
				$result = esc_url($uploadDir['baseurl'] . '/csp-product-list.csv');
			}
			wp_send_json($result);
		}

		/**
		 * Retrives all the simple & variable products' product IDs & Names
		 * and returns an array with product Id as a key & product title as a value
		 *
		 * @return array $products  array of productId-Name pairs
		 */
		private function wdmGetIdNamePairsForAllProducts()
		{
			global $wpdb;
			$parentVariations     = array();
			$parentVariationNames = array();
			$fullProductList      = array();

			$productsList =	$wpdb->get_results(
				'SELECT ID, post_title FROM ' . $wpdb->prefix .
					'posts where post_type="product" AND 
													post_status IN ("draft", "publish", "pending")'
			);

			$variantsList = $wpdb->get_results(
				'SELECT ID, post_parent FROM ' . $wpdb->prefix .
					'posts where post_type="product_variation" AND 
													post_status IN ("private", "publish", "pending")'
			);

			if ($variantsList) {
				foreach ($variantsList as $variant) {
					$parent = $variant->post_parent;
					if (!in_array($parent, $parentVariations, true)) {
						$parentVariations[] = $parent;
					}
				}
			}

			if ($productsList) {
				foreach ($productsList as $singleProduct) {
					$product_id = $singleProduct->ID;
					if (!empty($parentVariations) && in_array($product_id, $parentVariations, true)) {
						$parentVariationNames[$product_id] = $singleProduct->post_title;
					} else {
						$fullProductList[] = array($product_id, str_replace(',', '_', $singleProduct->post_title));
					}
				}
			}
			if ($variantsList) {
				foreach ($variantsList as $variant) {
					$variableProduct   = wc_get_product($variant->ID);
					$attributes        = $variableProduct->get_attributes();
					$fullProductList[] = array($variant->ID, str_replace(',', '_', $parentVariationNames[$variant->post_parent] . '-' . implode('_', $attributes)));
					unset($variableProduct);
				}
			}
			asort($fullProductList);
			return $fullProductList;
		}


		/**
		 * This is tha callback fucntion to the ajax based user search in the 
		 * search by & delete tab
		 *
		 * @return void
		 */
		public function getUsersBySearchTerm()
		{
			global $wpdb;
			$nonce 			   = isset($_REQUEST['nonce']) ? sanitize_text_field($_REQUEST['nonce']) : '';
			$nonceVerification = wp_verify_nonce($nonce, 'search-by-page-nonce');
			$searchTerm		   = isset($_REQUEST['search_term']) ? sanitize_text_field($_REQUEST['search_term']) : '';
			$users 			   = array();
			if ('' === $searchTerm) {
				$recentUsers = get_user_meta(get_current_user_id(), 'csp_search_by_recent_user_selections', true);
				if (!empty($recentUsers)) {
					$usersList = $wpdb->get_results($wpdb->prepare('SELECT id, CONCAT(user_login," <", user_email, ">") as text FROM ' . $wpdb->prefix . 'users WHERE id IN (' . implode(', ', array_fill(0, count($recentUsers), '%d')) . ') ORDER BY user_login', $recentUsers));
					wp_send_json($usersList);
				}
			}

			if (!is_multisite()) {
				$usersList = $wpdb->get_results($wpdb->prepare('SELECT id, CONCAT(user_login," <", user_email, ">") as text FROM ' . $wpdb->prefix . 'users WHERE user_login LIKE CONCAT(%s, %s, %s) OR user_email LIKE CONCAT(%s, %s, %s) ORDER BY user_login LIMIT 50', '%', $searchTerm, '%', '%', $searchTerm, '%'));
			} else {
				$capabilities = $wpdb->prefix . 'capabilities';
				$usersList    = $wpdb->get_results($wpdb->prepare('SELECT id, CONCAT(user_login," <", user_email, ">") as text FROM (SELECT id, user_login, user_email FROM ' . $wpdb->base_prefix . 'users u JOIN ' . $wpdb->base_prefix . 'usermeta um ON u.id=um.user_id WHERE um.meta_key=%s) AS csp_user_query WHERE user_login LIKE CONCAT(%s, %s, %s) OR user_email LIKE CONCAT(%s, %s, %s) ORDER BY user_login LIMIT 50', $capabilities, '%', $searchTerm, '%', '%', $searchTerm, '%'));
			}
			wp_send_json($usersList);
		}


		/**
		 * Saves the selected user Id into the recently searched users list
		 * if the size of the list is 
		 *
		 * @param int $userId user Id to be stored.
		 * @return void
		 */
		private function saveRecentSearches($userId)
		{
			/**
			 * Search by feature for the users stores the recent 10 searchases made by the user, 
			 * this filter can be used change this number.
			 * 
			 * @param int $number number of recent username searches to store.
			 */
			$maxSizeOfRecentUsers = apply_filters('csp_search_by_recent_user_selections_max_size', 10);
			if (!empty($userId)) {
				$recentUsers = get_user_meta(get_current_user_id(), 'csp_search_by_recent_user_selections', true);
				if (!empty($recentUsers) && !in_array($userId, $recentUsers, true)) {
					if (\count($recentUsers) < $maxSizeOfRecentUsers) {
						$recentUsers[] = $userId;
					} else {
						$newUserList = array();
						for ($i = 1; $i < $maxSizeOfRecentUsers; $i++) {
							$newUserList[] = $recentUsers[$i];
						}
						$newUserList[] = $userId;
						$recentUsers  = $newUserList;
					}
				} else {
					if (is_array($recentUsers)) {
						$recentUsers[] = $userId;
					} else {
						$recentUsers = array($userId);
					}
				}
				update_user_meta(get_current_user_id(), 'csp_search_by_recent_user_selections', $recentUsers);
			}
		}


		/** 
		 * This function generates csvs for all the rule types & creates an arhieve of all the files
		 * and returns the downlodable path for the same.  
		 */
		public function wdmCreateBackupForAllRules()
		{
			$nonce              = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');
			/**
			 * This filter can be used to Override nonce verification for extending import functionality in
			 * any third party extension.
			 * 
			 * @param bool|string $name $nonce_verification nonce name or false to disable nonce verification
			 */
			$nonce_verification = apply_filters('csp_export_nonce_verification', $nonce_verification);
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}

			include_once CSP_PLUGIN_PATH . '/includes/import-export/export/class-export-all.php';
			if (\class_exists('\cspImportExport\cspExport\WdmWuspExportAll')) {
				$exportObject = new \cspImportExport\cspExport\WdmWuspExportAll();
				$exportObject->generateBackup();
				if ('' !== $exportObject->getFileUrl()) {
					echo esc_url($exportObject->getFileUrl());
				} else {
					echo esc_html__('Unable to create backup of all the rules or no CSP rules were found.', 'customer-specific-pricing-for-woocommerce');
				}
			}
			exit();
		}



		/**
		 * This is ajax callback for the actiuon 'csp_get_import_csv', this method is used to get the CSV file
		 * in the upload request, validate the file if it is import ready, save the valid file to the temporary upload
		 * directory and send ajax response with status & file path.
		 *
		 * @since 4.6.3 
		 */
		public function cspGetValidateImportCSV()
		{
			$nonce 			   = isset($_REQUEST['import_nonce']) ? sanitize_text_field($_REQUEST['import_nonce']) : '';
			$nonceVerification = wp_verify_nonce($nonce, 'wdm-csp-import');
			/**
			 * Filter to override the nonce verification.
			 *
			 * @param int|false 1 if the nonce is valid and generated between 0-12 hours ago, 2 if the nonce is valid and generated between 12-24 hours ago. False if the nonce is invalid
			 */
			$nonceVerification = apply_filters('csp_import_nonce_verification', $nonceVerification);
			$uploadsDir 	   = wp_upload_dir();

			/**
			 * Filter which can be used to change the default temporary storage directory name of the import file before import
			 * 
			 * @param string $name directory name.
			 */
			$rawImportFilesDir = apply_filters('wdm_csp_filter_new_import_raw_upload_path', 'csp-import-files');

			/**
			 * Filter which can be used to change the default temporary storage file name of the import file before import
			 * 
			 * @param string $name file name.
			 */
			$rawImportFileName = apply_filters('wdm_csp_filter_new_import_raw_file_name', 'current_csp_import');
			$rawImportFileName = $rawImportFileName . '.csv';

			if (!$nonceVerification) {
				$error = new \WP_Error('0001', __('Security Error, Nonce verification failed', 'customer-specific-pricing-for-woocommerce'), __('Please check if the user has permission to import the CSV files', 'customer-specific-pricing-for-woocommerce'));
				wp_send_json_error($error);
			}


			if (!empty($uploadsDir['error'])) {
				$error = new \WP_Error('0002', __('Unable to get the upload directory', 'customer-specific-pricing-for-woocommerce'));
				wp_send_json_error($error);
			}

			//Validate & save the file by extension.
			$fileName     	   = isset($_FILES['file']['name']) ? sanitize_text_field($_FILES['file']['name']) : '';
			$fileTempName 	   = isset($_FILES['file']['tmp_name']) ? sanitize_text_field($_FILES['file']['tmp_name']) : '';
			$rawImportFilesDir = $uploadsDir['basedir'] . '/' . $rawImportFilesDir;
			$filePath     	   = $rawImportFilesDir . '/' . $fileName;

			$fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
			$fileExtension = strtolower($fileExtension);
			if ('csv' != $fileExtension) {
				$error = new \WP_Error('0003', __('Only csv files are supported for the CSP rule imports please check if you have selected the correct file', 'customer-specific-pricing-for-woocommerce'));
				wp_send_json_error($error);
			}

			if (!is_dir($rawImportFilesDir) && !\mkdir($rawImportFilesDir)) {
				$error = new \WP_Error('0004', __('Failed to create upload directory', 'customer-specific-pricing-for-woocommerce'));
				wp_send_json_error($error);
			}

			$filePath     	   = $rawImportFilesDir . '/' . $rawImportFileName;
			if (move_uploaded_file($fileTempName, $filePath)) {
				require_once CSP_PLUGIN_PATH . '/includes/import-export/import-new/class-wdm-import.php';
				$importManager = new \cspImportExport\Import\WisdmCSPImport();
				$fileDetails   = $importManager->validateImportFile($rawImportFileName, $filePath);
				if (!$fileDetails['success']) {
					$error = new \WP_Error('0005', __($fileDetails['data'], 'customer-specific-pricing-for-woocommerce'));
					wp_send_json_error($error);
				}

				//$importQueue = $importManager->addImportFileToTheQueue($fileDetails['data']);

				$response 	   = array('data' => $fileDetails);
			}

			wp_send_json_success($response);
		}

		/**
		 * Starts the import process from the import page, generates the batches according to the settings
		 * and sends the list of batches with rule count.
		 *
		 * @since 4.6.3
		 */
		public function startImportProcess()
		{
			$nonce 			   = isset($_REQUEST['import_nonce']) ? sanitize_text_field($_REQUEST['import_nonce']) : '';
			$nonceVerification = wp_verify_nonce($nonce, 'wdm-csp-import');
			/**
			 * Filter to override the nonce verification.
			 *
			 * @param int|false 1 if the nonce is valid and generated between 0-12 hours ago, 2 if the nonce is valid and generated between 12-24 hours ago. False if the nonce is invalid
			 */
			$nonceVerification = apply_filters('csp_import_nonce_verification', $nonceVerification);
			if (!$nonceVerification) {
				$error = new \WP_Error('0001', __('Security Error, Nonce verification failed', 'customer-specific-pricing-for-woocommerce'), __('Please check if the user has permission to import the CSV files', 'customer-specific-pricing-for-woocommerce'));
				wp_send_json_error($error);
			}

			$postArray = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			$fileDetails = isset($postArray['file_details']) ? $postArray['file_details'] : '';

			if (!empty($fileDetails)) {
				require_once CSP_PLUGIN_PATH . '/includes/import-export/import-new/class-wdm-import.php';
				$filePath  = $fileDetails['file_path'];
				$fileType  = $fileDetails['type'];
				$headerMap = $fileDetails['valid_headers_file_columns_mapping'];

				$importManager = new \cspImportExport\Import\WisdmCSPImport();
				$status 	   = $importManager->splitLargeCSVImportFile($filePath, $fileType, $headerMap);
			}
			wp_send_json($status);
		}

		/**
		 * This function on called import the batch sent as the POST parameter & 
		 * sends back the status of the import to the ajax request.
		 * 
		 * @since 4.6.3
		 */
		public function startBatchImport()
		{
			global $cspFunctions;
			$nonce 			   = isset($_REQUEST['import_nonce']) ? sanitize_text_field($_REQUEST['import_nonce']) : '';
			$nonceVerification = wp_verify_nonce($nonce, 'wdm-csp-import');
			/**
			 * Filter to override the nonce verification.
			 *
			 * @param int|false 1 if the nonce is valid and generated between 0-12 hours ago, 2 if the nonce is valid and generated between 12-24 hours ago. False if the nonce is invalid
			 */
			$nonceVerification = apply_filters('csp_import_nonce_verification', $nonceVerification);
			if (!$nonceVerification) {
				$error = new \WP_Error('0001', __('Security Error, Nonce verification failed', 'customer-specific-pricing-for-woocommerce'), __('Please check if the user has permission to import the CSV files', 'customer-specific-pricing-for-woocommerce'));
				wp_send_json_error($error);
			}

			$requestData = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$batchType   = isset($requestData['batchDetails']['ruleType']) ? $requestData['batchDetails']['ruleType'] : 'usp-product';
			$batchName   = isset($requestData['batchDetails']['batchName']) ? $requestData['batchDetails']['batchName'] : '';
			$headerMap	 = isset($requestData['batchDetails']['headerMap']) ? $requestData['batchDetails']['headerMap'] : '';

			$classFile = CSP_PLUGIN_PATH . '/includes/import-export/import-new/file-type-imports/class-import-' . $batchType . '.php';

			include_once CSP_PLUGIN_PATH . '/includes/import-export/import-new/file-type-imports/abstract-class-import-file.php';
			include_once $classFile;
			$class = '\cspImportExport\Import\FileTypeImport\\' . $cspFunctions::getCamelCaseOfDashCase($batchType) . 'Import';

			$importObject = new $class();
			$importStatus = $importObject->ImportFile($batchName, $batchType, $headerMap);

			$response = array(
				'requestData' => $requestData['batchDetails'],
				'status' => $importStatus,
			);
			wp_send_json_success($response);
		}


		/**
		 * Generates a csv report by merging all the report containing batches.
		 * * Verify the nonce
		 * * gets report directory, deletes the report result file if exists.
		 * * fetches paths of all the files in the reports directory.
		 * * merge all the report batch files using method joinFiles.
		 * * returns the download path for the merged report file.
		 *
		 * @since 4.6.3
		 * @return void
		 */
		public function generateAndDownloadImportReport()
		{
			$importNonce = isset($_REQUEST['_wp_import_nonce']) ? sanitize_text_field($_REQUEST['_wp_import_nonce']) : '';
			$nonceVerification = wp_verify_nonce($importNonce, 'wdm-csp-import');

			/**
			 * Filter to override the nonce verification.
			 *
			 * @param int|false 1 if the nonce is valid and generated between 0-12 hours ago, 2 if the nonce is valid and generated between 12-24 hours ago. False if the nonce is invalid
			 */
			$nonceVerification = apply_filters('csp_import_nonce_verification', $nonceVerification);
			if (!$nonceVerification) {
				echo 'Security Check';
				exit;
			}

			$uploadDir = wp_upload_dir();
			$reportsDir     = $uploadDir['basedir'] . '/csp-import-files/batch_files';
			$mergedReportFile   = $reportsDir . '/detailedReport.csv';
			if (file_exists($mergedReportFile)) {
				unlink($mergedReportFile);
			}

			$allBatches = glob($reportsDir . '/*.csv');
			$this->joinFiles($allBatches, $mergedReportFile);

			$reportFileUrl = $uploadDir['baseurl'] . '/csp-import-files/batch_files/detailedReport.csv';
			echo esc_url($reportFileUrl);
			die();
		}

		/**
		 * Saves the schedule data for the CSP rule bakup as defined by the admin, also 
		 * creates a action scheduler action for generation of the backup.
		 * 
		 * @since 4.6.3
		 */
		public function saveBackupSchedule()
		{
			global $cspFunctions;
			$nonce              = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}

			$requestData = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			$frequency  = isset($requestData['frequency']) ? $requestData['frequency'] : '';
			$weekDay    = isset($requestData['week_day']) ? $requestData['week_day'] : '';
			$time       = isset($requestData['backup_time']) ? $requestData['backup_time'] : '00:00';
			$maxBackups = isset($requestData['backup_limit']) ? $requestData['backup_limit'] : 5;

			$timePattern = '/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/';
			$validTime   = preg_match($timePattern, $time);

			$scheduleData = array('frequency' => $frequency, 'weekDay' => $weekDay, 'time' => $time, 'maxBackups' => $maxBackups);
			update_option('wdm_csp_backup_schedule', $scheduleData);

			//Scheduling the job using action scheduler
			$currentTime    = current_time('timestamp');
			$timeToday 	    = strtotime(current_time('Y-m-d'));
			$time 		    = explode(':', $time);
			$hour 		    = (int) $time[0] * 60 * 60;
			$minute 	    = (int) $time[1] * 60;
			$time   	    = $hour + $minute;
			$nextBackupTime = '';
			as_unschedule_all_actions('wdm_csp_generate_scheduled_backup', array(), 'csp_backups');
			if ('daily' == $frequency) {
				$scheduledTimeOfTheDay = $timeToday + $time;
				$nextBackupTime 	   = $scheduledTimeOfTheDay;
				if ($scheduledTimeOfTheDay < $currentTime) {
					$nextBackupTime = $scheduledTimeOfTheDay + 86400;
				}

				$nextBackupTime = $cspFunctions->convertToUTC($nextBackupTime);
				as_schedule_recurring_action($nextBackupTime, 86400, 'wdm_csp_generate_scheduled_backup', array(), 'csp_backups');
				$response = array(
					'status' => 'success',
				);
			} elseif ('weekly' == $frequency) {
				$weekDayToday =  current_time('w');
				if ($weekDayToday == $weekDay) {
					$scheduledTimeOfTheDay = $timeToday + $time;
					$nextBackupTime 	   = $scheduledTimeOfTheDay;
					if ($scheduledTimeOfTheDay < $currentTime) {
						$nextBackupTime = $scheduledTimeOfTheDay + 604800;
					}
				} else {
					$scheduledTimeOfTheDay = $timeToday + $time;
					$nextBackupTime = $scheduledTimeOfTheDay + (((7 - $weekDayToday + $weekDay) % 7) * 86400);
				}

				$nextBackupTime = $cspFunctions->convertToUTC($nextBackupTime);
				as_schedule_recurring_action($nextBackupTime, 604800, 'wdm_csp_generate_scheduled_backup', array(), 'csp_backups');
				$response = array(
					'status' => 'success',
				);
			}


			wp_send_json_success($response);
		}


		/**
		 * This function is used to the scheduled action 'wdm_csp_generate_scheduled_backup',
		 * on called by the Action scheduler of WP cron it generates the backup file & saves
		 * the file according to the rules defined.
		 *
		 * @return void
		 */
		public function generateScheduledBackup()
		{
			include_once CSP_PLUGIN_PATH . '/includes/import-export/export/class-export-all.php';
			$fileName = 'auto-backup_' . date_i18n('U') . '.zip';
			$scheduleDetails = get_option('wdm_csp_backup_schedule', array());
			$maxBackups 	 = !empty($scheduleDetails['maxBackups']) ? $scheduleDetails['maxBackups'] : 5;

			if (\class_exists('\cspImportExport\cspExport\WdmWuspExportAll')) {
				$exportObject = new \cspImportExport\cspExport\WdmWuspExportAll();
				$exportObject->setFileName($fileName);
				$exportObject->generateBackup();
				if ('' !== $exportObject->getFilePath()) {
					$exportObject->autoBackupFileStorage($maxBackups, $exportObject->getFilePath(), $fileName);
					/**
					 * This action can be used for the tasks like geting alerts on automatic 
					 * backup creation 
					 * 
					 * @param string $name name of the backup file. 
					 */
					do_action('wdm_csp_auomatic_backup_created', $exportObject->getFileName());
				} else {
					/**
					 * This action can be used for the tasks like geting alerts on automatic 
					 * backup creation failure 
					 * 
					 * @param string $time timestamp when the operation fails. 
					 */
					do_action('wdm_csp_auomatic_backup_failed', date_i18n('U'));
				}
			}
		}


		/**
		 * Removes the backup schedules added previously.
		 * 
		 * @since 4.6.3
		 */
		public function stopBackupSchedule()
		{
			$nonce              = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}
			as_unschedule_all_actions('wdm_csp_generate_scheduled_backup', array(), 'csp_backups');
			delete_option('wdm_csp_backup_schedule');
			$response = array(
				'status' => 'success',
			);
			wp_send_json_success($response);
		}


		/**
		 * This function is the ajax callback used to process the delete operation on the backup files
		 * generated by the automatic backup function.
		 *
		 * @since 4.6.3
		 */
		public function removeBackupFile()
		{
			$nonce              = isset($_REQUEST['_wpnonce']) ? sanitize_text_field($_REQUEST['_wpnonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'export_nonce');
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}

			$fileName = isset($_POST['file_name']) ? sanitize_text_field($_POST['file_name']) : '';
			if (!empty($fileName)) {
				$filePath = WP_CONTENT_DIR . '/csp_backups/' . $fileName;
				if (\is_file($filePath)) {
					\unlink($filePath);
				}

				$response = array('status' => 'success',);
				wp_send_json_success($response);
			}

			$error = new \WP_Error('0006', __('The requested file not found or already deleated.', 'customer-specific-pricing-for-woocommerce'));
			wp_send_json_error($error);
		}


		/**
		 * Verifies if the credentials are working by testing the FTP/SFTP connection.
		 *
		 * @since 4.6.3
		 */
		public function checkFTPConnection()
		{
			$nonce              = isset($_REQUEST['_wp_import_nonce']) ? sanitize_text_field($_REQUEST['_wp_import_nonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'wdm-csp-import');
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}

			$postData		= filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			$connectionType = isset($postData['connection']) ? $postData['connection'] : 'ftp';
			$defaultPort    = 'sftp' == $connectionType ? 22 : 21;
			$ftpUrl			= isset($postData['url']) ? $postData['url'] : '';
			$ftpPort		= isset($postData['port']) ? $postData['port'] : $defaultPort;
			$userName		= isset($postData['user_name']) ? $postData['user_name'] : '';
			$password		= isset($postData['password']) ? $postData['password'] : '';
			$filePath		= isset($postData['file_path']) ? $postData['file_path'] : '';
			$connection 	= false;

			if ('ftp' == $connectionType) {
				$connection = $this->ftpConnectionCheck($ftpUrl, $ftpPort, $userName, $password);
			} elseif ('sftp' == $connectionType) {
				$connection = $this->sftpConnectionCheck($ftpUrl, $ftpPort, $userName, $password);
			}

			if ($connection) {
				$response = array('status' => 'success',);
			} else {
				$response = array('status' => 'failure', 'error_message' => __('Unable to connect using the FTP details provided, please verify the same.', 'customer-specific-pricing-for-woocommerce'));
			}

			wp_send_json_success($response);
		}

		/**
		 * Checks if the configuration provided for the FTP is 
		 * working as expected.
		 *
		 * @since 4.6.3
		 * @param string $host
		 * @param int $port
		 * @param string $userName
		 * @param string $password
		 */
		public function ftpConnectionCheck($host, $port, $userName, $password)
		{
			$port          = empty($port) ? 21 : $port;
			$host 		   = str_replace('ftp://', '', $host);
			$host 		   = rtrim($host, '/');
			$ftpConnection = false;
			$connect 	   = false;
			try {
				$ftpConnection = ftp_connect($host, $port, 45);
				if (!empty($ftpConnection) && ftp_login($ftpConnection, $userName, $password)) {
					$connect =  true;
				} else {
					$ftpConnection = ftp_ssl_connect($host, $port, 45);
					if (!empty($ftpConnection) && ftp_login($ftpConnection, $userName, $password)) {
						$connect =  true;
					}
				}
				ftp_close($ftpConnection);
			} catch (\Throwable $th) {
				$connect = false;
			}

			return $connect;
		}

		/**
		 * Uses phpseclib to check if the configuration provided for the SFTP is 
		 * working as expected.
		 *
		 * @since 4.6.3
		 * @param string $host
		 * @param int $port
		 * @param string $userName
		 * @param string $password
		 */
		public function sftpConnectionCheck($host, $port, $userName, $password)
		{
			if (!function_exists('ssh2_connect')) {
				return false;
			}
			$host 	 = str_replace('sftp://', '', $host);
			$host 	 = str_replace('ftp://', '', $host);
			$host 	 = rtrim($host, '/');
			$connect = false;
			$port	 = empty($port) ? 22 : (int) $port;
			$sftp 	 = ssh2_connect($host, $port);

			if (!empty($sftp) && ssh2_auth_password($sftp, $userName, $password)) {
				$connect = true;
			}
			ssh2_disconnect($sftp);
			return $connect;
		}


		/**
		 * Adds a action scheduler action to import the data & saves the scheduled data
		 * 
		 * @since 4.6.3
		 * @return void
		 */
		public function saveUpdateImportSchedule()
		{
			$nonce              = isset($_REQUEST['_wp_import_nonce']) ? sanitize_text_field($_REQUEST['_wp_import_nonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'wdm-csp-import');
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}

			$postData = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
			include_once CSP_PLUGIN_PATH . '/includes/import-export/import-new/class-scheduled-imports.php';
			$importScheduleObject = new \cspImportExport\Import\WisdmCSPScheduledImports();
			$response = $importScheduleObject->scheduleImport($postData);

			wp_send_json_success($response);
		}

		public function deleteImportSchedule()
		{
			$nonce              = isset($_REQUEST['_wp_import_nonce']) ? sanitize_text_field($_REQUEST['_wp_import_nonce']) : '';
			$nonce_verification = wp_verify_nonce($nonce, 'wdm-csp-import');
			if (!$nonce_verification) {
				esc_html_e('Security Check', 'customer-specific-pricing-for-woocommerce');
				exit;
			}
			$postData = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

			if (isset($postData['schedule_id']) && !empty($postData['schedule_id'])) {
				include_once CSP_PLUGIN_PATH . '/includes/import-export/import-new/class-scheduled-imports.php';
				$importScheduleObject = new \cspImportExport\Import\WisdmCSPScheduledImports();
				$response 			  = $importScheduleObject->deleteScheduledImport($postData['schedule_id']);
			}

			wp_send_json_success($response);
		}


		/**
		 * This action is hooked to the action scheduler hook 'wdm_csp_process_rule_import'
		 * & gets triggered when action scheduler triigers the job as per the schedule.
		 * This menthod process the import operation as per the shcedule.
		 *
		 * @since 4.6.3
		 * @param string $scheduleDataOption Name of the scheduled action
		 * @return void
		 */
		public function importScheduledFile($scheduleDataOption = '')
		{
			if (empty($scheduleDataOption)) {
				return;
			}

			include_once CSP_PLUGIN_PATH . '/includes/import-export/import-new/class-scheduled-imports.php';
			$importScheduleObject = new \cspImportExport\Import\WisdmCSPScheduledImports();
			$importStatus		  = $importScheduleObject->importFileForTheSchedule($scheduleDataOption);

			/**
			 * This action gets executed when the scheduled import action gets triggered
			 * 
			 * @param array $importStatus array(status,import_status,report_file, report_dir')
			 */
			do_action('wdm_csp_scheduled_import_status', $importStatus, $scheduleDataOption);
		}
	}
}
