<?php

//silence is Golden
