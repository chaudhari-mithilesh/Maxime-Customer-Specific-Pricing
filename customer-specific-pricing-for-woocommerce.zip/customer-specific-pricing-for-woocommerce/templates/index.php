<?php

//silence is Golden
